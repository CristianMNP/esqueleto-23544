package ar.com.codoacodo.interfaces;

//ESTO ES EL CONTRATO
public interface ILogger {
	//QUE
	public void log();
}
