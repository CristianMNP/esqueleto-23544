package ar.com.codoacodo.herencia;

public class Mainv2 {

	public Mainv2() {
		// TODO Auto-generated constructor stub
	}

}