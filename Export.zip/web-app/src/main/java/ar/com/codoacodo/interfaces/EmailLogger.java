package ar.com.codoacodo.interfaces;

public class EmailLogger implements ILogger {

	//COMO
	public void log() {
		System.out.println("Enviando mail a mail@mail.com");
	}

}

